package com.example.catwalkers

import android.animation.Animator
import android.animation.AnimatorListenerAdapter
import android.animation.ValueAnimator
import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Intent
import android.content.pm.ServiceInfo
import android.graphics.Bitmap
import android.graphics.PixelFormat
import android.graphics.drawable.Icon
import android.os.Build
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.provider.Settings
import android.view.Gravity
import android.view.ViewGroup
import android.view.WindowManager
import android.view.animation.LinearInterpolator
import android.widget.FrameLayout
import kotlin.math.abs
import kotlin.random.Random

class CatService : Service() {

    companion object {
        @Volatile
        var running = false
        const val PREFS = "cats"
        const val KEY_AVG = "avg_seconds"
        const val KEY_DRAWN = "drawn_too"
        const val ACTION_STOP = "com.example.catwalkers.STOP"
        private const val CHANNEL_ID = "cats"
    }

    private lateinit var wm: WindowManager
    private var container: FrameLayout? = null
    private val handler = Handler(Looper.getMainLooper())
    private val animators = mutableSetOf<ValueAnimator>()
    private val bitmapCache = HashMap<String, Bitmap>()
    private var alive = false

    private val palette = intArrayOf(
        0xFFF4A64B.toInt(), // рыжий
        0xFF9AA0A6.toInt(), // серый
        0xFF3A3A3F.toInt(), // чёрный
        0xFFF5F5F5.toInt(), // белый
        0xFFB07A4F.toInt()  // коричневый
    )

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onCreate() {
        super.onCreate()
        startAsForeground()

        if (!Settings.canDrawOverlays(this)) {
            stopSelf()
            return
        }

        wm = getSystemService(WINDOW_SERVICE) as WindowManager
        val c = FrameLayout(this)
        val lp = WindowManager.LayoutParams(
            ViewGroup.LayoutParams.MATCH_PARENT,
            ViewGroup.LayoutParams.MATCH_PARENT,
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                    WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE or
                    WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN or
                    WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
            PixelFormat.TRANSLUCENT
        )
        lp.gravity = Gravity.TOP or Gravity.START
        wm.addView(c, lp)
        container = c

        alive = true
        running = true
        scheduleNext(first = true)
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (intent?.action == ACTION_STOP) {
            stopSelf()
        }
        return START_NOT_STICKY
    }

    override fun onDestroy() {
        alive = false
        running = false
        handler.removeCallbacksAndMessages(null)
        animators.toList().forEach { it.cancel() }
        animators.clear()
        container?.let {
            try {
                wm.removeView(it)
            } catch (_: Exception) {
            }
        }
        container = null
        bitmapCache.clear()
        super.onDestroy()
    }

    // ---------- уведомление ----------

    private fun startAsForeground() {
        val nm = getSystemService(NotificationManager::class.java)
        nm.createNotificationChannel(
            NotificationChannel(CHANNEL_ID, "Котики", NotificationManager.IMPORTANCE_LOW)
        )
        val stopPi = PendingIntent.getService(
            this, 0,
            Intent(this, CatService::class.java).setAction(ACTION_STOP),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )
        val openPi = PendingIntent.getActivity(
            this, 1, Intent(this, MainActivity::class.java), PendingIntent.FLAG_IMMUTABLE
        )
        val stopAction = Notification.Action.Builder(
            Icon.createWithResource(this, android.R.drawable.ic_menu_close_clear_cancel),
            "Остановить", stopPi
        ).build()

        val n = Notification.Builder(this, CHANNEL_ID)
            .setSmallIcon(android.R.drawable.star_on)
            .setContentTitle("Котики гуляют по экрану")
            .setContentText("Нажмите, чтобы настроить")
            .setContentIntent(openPi)
            .addAction(stopAction)
            .setOngoing(true)
            .build()

        if (Build.VERSION.SDK_INT >= 34) {
            startForeground(1, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE)
        } else {
            startForeground(1, n)
        }
    }

    // ---------- котики ----------

    private fun dp(v: Float) = v * resources.displayMetrics.density

    private fun scheduleNext(first: Boolean = false) {
        val avg = getSharedPreferences(PREFS, MODE_PRIVATE).getInt(KEY_AVG, 30)
        val delay = if (first) 2000L else (avg * 1000L * (0.5 + Random.nextDouble())).toLong()
        handler.postDelayed({
            if (alive) {
                spawnCat()
                scheduleNext()
            }
        }, delay)
    }

    private class Pick(
        val walk: Bitmap,
        val rest: Bitmap?,
        val restFactor: Float,
        val swing: Boolean
    )

    private fun bitmapOf(e: CatStore.Entry): Bitmap? {
        val cached = bitmapCache[e.file.path]
        if (cached != null) return cached
        val bmp = CatStore.load(e.file) ?: return null
        bitmapCache[e.file.path] = bmp
        return bmp
    }

    /** Случайный фото-котик (все его позы) или null, если надо показать нарисованного. */
    private fun pickPhotoCat(): Pick? {
        val entries = CatStore.entries(this)
        if (entries.isEmpty()) return null
        val drawnToo = getSharedPreferences(PREFS, MODE_PRIVATE).getBoolean(KEY_DRAWN, false)
        if (drawnToo && Random.nextFloat() < 0.25f) return null

        // выбираем кошку по имени, чтобы все кошки выходили одинаково часто
        val group = entries.groupBy { it.name }.values.toList().random()
        val walks = group.filter { it.pose == "walk" }
        val base = (if (walks.isEmpty()) group else walks).random()
        val rest = group.filter { it !== base && it.pose != "walk" }.randomOrNull()

        val walkBmp = bitmapOf(base) ?: return null
        val restBmp = if (rest != null) bitmapOf(rest) else null
        val factor = if (rest?.pose == "sit") 0.8f else 0.9f
        return Pick(walkBmp, restBmp, factor, base.pose == "walk")
    }

    private fun spawnCat() {
        val c = container ?: return
        val dm = resources.displayMetrics
        val w = if (c.width > 0) c.width.toFloat() else dm.widthPixels.toFloat()
        val h = if (c.height > 0) c.height.toFloat() else dm.heightPixels.toFloat()

        val pick = pickPhotoCat()
        val cat: CatBase
        val wPx: Int
        val hPx: Int
        if (pick != null) {
            val longSide = dp(Random.nextInt(90, 130).toFloat())
            val d = PhotoCatView.fit(pick.walk, longSide)
            wPx = d[0]
            hPx = d[1]
            cat = PhotoCatView(this, pick.walk, pick.rest, longSide, pick.restFactor, pick.swing)
        } else {
            wPx = dp(Random.nextInt(70, 120).toFloat()).toInt()
            hPx = (wPx * 0.72f).toInt()
            cat = CatView(this, palette.random())
        }
        c.addView(cat, FrameLayout.LayoutParams(wPx, hPx))

        // чаще бегают «по полу» внизу экрана, но иногда где угодно
        val y = if (Random.nextFloat() < 0.6f) {
            h * (0.65f + Random.nextFloat() * 0.3f) - hPx
        } else {
            Random.nextFloat() * (h - hPx)
        }
        cat.translationY = y.coerceAtLeast(0f)

        val fromLeft = Random.nextBoolean()
        val startX = if (fromLeft) -wPx.toFloat() else w
        val farX = if (fromLeft) w else -wPx.toFloat()
        cat.scaleX = if (fromLeft) 1f else -1f
        cat.translationX = startX

        val speed = dp(Random.nextInt(50, 100).toFloat()) // пикселей в секунду
        val mid = startX + (farX - startX) * (0.25f + Random.nextFloat() * 0.5f)
        val roll = Random.nextFloat()

        when {
            // зашёл, посидел, развернулся и ушёл обратно
            roll < 0.3f -> walk(cat, mid, speed) {
                sit(cat, Random.nextLong(2000, 4500)) {
                    cat.scaleX = -cat.scaleX
                    walk(cat, startX, speed) { removeCat(cat) }
                }
            }
            // прошёл с остановкой посередине
            roll < 0.6f -> walk(cat, mid, speed) {
                sit(cat, Random.nextLong(2000, 4500)) {
                    walk(cat, farX, speed) { removeCat(cat) }
                }
            }
            // просто прошёл мимо
            else -> walk(cat, farX, speed) { removeCat(cat) }
        }
    }

    private fun walk(cat: CatBase, toX: Float, speed: Float, onDone: () -> Unit) {
        val from = cat.translationX
        val dist = abs(toX - from)
        cat.walking = true
        val a = ValueAnimator.ofFloat(from, toX)
        a.duration = (dist / speed * 1000f).toLong().coerceAtLeast(1L)
        a.interpolator = LinearInterpolator()
        a.addUpdateListener { cat.translationX = it.animatedValue as Float }
        a.addListener(object : AnimatorListenerAdapter() {
            private var cancelled = false
            override fun onAnimationCancel(animation: Animator) {
                cancelled = true
            }

            override fun onAnimationEnd(animation: Animator) {
                animators.remove(a)
                if (alive && !cancelled) onDone()
            }
        })
        animators.add(a)
        a.start()
    }

    private fun sit(cat: CatBase, ms: Long, onDone: () -> Unit) {
        cat.walking = false
        handler.postDelayed({ if (alive) onDone() }, ms)
    }

    private fun removeCat(cat: CatBase) {
        container?.removeView(cat)
    }
}
