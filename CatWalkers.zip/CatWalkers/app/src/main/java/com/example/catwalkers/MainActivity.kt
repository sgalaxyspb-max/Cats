package com.example.catwalkers

import android.Manifest
import android.app.Activity
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.view.Gravity
import android.widget.Button
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.SeekBar
import android.widget.TextView
import android.widget.Toast

class MainActivity : Activity() {

    private lateinit var status: TextView

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val prefs = getSharedPreferences(CatService.PREFS, MODE_PRIVATE)

        val col = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER_HORIZONTAL
            setPadding(dp(24), dp(48), dp(24), dp(24))
        }

        col.addView(TextView(this).apply {
            text = "🐈 Котики на экране"
            textSize = 26f
            gravity = Gravity.CENTER
        })

        status = TextView(this).apply {
            textSize = 16f
            gravity = Gravity.CENTER
            setPadding(0, dp(16), 0, dp(24))
        }
        col.addView(status)

        val start = Button(this).apply { text = "Запустить котиков" }
        val stop = Button(this).apply { text = "Прогнать котиков" }
        col.addView(start)
        col.addView(stop)

        val label = TextView(this).apply {
            textSize = 15f
            setPadding(0, dp(32), 0, dp(8))
        }
        val avg = prefs.getInt(CatService.KEY_AVG, 30)
        label.text = "Котик приходит примерно раз в $avg с"
        val seek = SeekBar(this).apply {
            max = 110
            progress = avg - 10
            setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
                override fun onProgressChanged(sb: SeekBar, p: Int, fromUser: Boolean) {
                    val v = p + 10
                    prefs.edit().putInt(CatService.KEY_AVG, v).apply()
                    label.text = "Котик приходит примерно раз в $v с"
                }

                override fun onStartTrackingTouch(sb: SeekBar) {}
                override fun onStopTrackingTouch(sb: SeekBar) {}
            })
        }
        col.addView(label)
        col.addView(seek)

        setContentView(ScrollView(this).apply { addView(col) })

        start.setOnClickListener {
            if (!Settings.canDrawOverlays(this)) {
                Toast.makeText(
                    this,
                    "Разрешите показ поверх других окон и вернитесь в приложение",
                    Toast.LENGTH_LONG
                ).show()
                startActivity(
                    Intent(
                        Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
                        Uri.parse("package:$packageName")
                    )
                )
                return@setOnClickListener
            }
            if (Build.VERSION.SDK_INT >= 33 &&
                checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) !=
                PackageManager.PERMISSION_GRANTED
            ) {
                requestPermissions(arrayOf(Manifest.permission.POST_NOTIFICATIONS), 1)
            }
            startForegroundService(Intent(this, CatService::class.java))
            status.postDelayed({ refresh() }, 600)
        }

        stop.setOnClickListener {
            stopService(Intent(this, CatService::class.java))
            status.postDelayed({ refresh() }, 300)
        }
    }

    override fun onResume() {
        super.onResume()
        refresh()
    }

    private fun refresh() {
        status.text = when {
            !Settings.canDrawOverlays(this) -> "Нужно разрешение «Поверх других окон»"
            CatService.running -> "Котики гуляют 🐾"
            else -> "Котики спят 😴"
        }
    }
}
