package com.example.catwalkers

import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import java.io.File
import java.io.FileOutputStream

/**
 * Хранит вырезанных котиков в виде PNG.
 * Имя файла: <время>_<имя>_<поза>.png, поза: walk (идёт боком), sit (сидит), lie (лежит).
 */
object CatStore {

    data class Entry(val file: File, val name: String, val pose: String)

    private fun dir(ctx: Context): File = File(ctx.filesDir, "cats").apply { mkdirs() }

    fun list(ctx: Context): List<File> =
        dir(ctx).listFiles { f -> f.extension == "png" }?.sortedBy { it.name } ?: emptyList()

    fun entries(ctx: Context): List<Entry> = list(ctx).map { parse(it) }

    fun parse(f: File): Entry {
        val parts = f.nameWithoutExtension.split('_')
        return when {
            parts.size >= 3 -> Entry(f, parts.subList(1, parts.size - 1).joinToString("_"), parts.last())
            parts.size == 2 -> Entry(f, parts[1], "walk")
            else -> Entry(f, "Котик", "walk")
        }
    }

    fun poseLabel(pose: String): String = when (pose) {
        "sit" -> "сидит"
        "lie" -> "лежит"
        else -> "идёт боком"
    }

    fun displayName(f: File): String {
        val e = parse(f)
        return "${e.name} · ${poseLabel(e.pose)}"
    }

    fun save(ctx: Context, bmp: Bitmap, name: String, pose: String): File {
        val safe = name.replace(Regex("[\\\\/:*?\"<>|_]"), "").trim().ifEmpty { "Котик" }
        val f = File(dir(ctx), "${System.currentTimeMillis()}_${safe}_$pose.png")
        FileOutputStream(f).use { bmp.compress(Bitmap.CompressFormat.PNG, 100, it) }
        return f
    }

    fun delete(f: File) {
        f.delete()
    }

    fun load(f: File): Bitmap? = BitmapFactory.decodeFile(f.path)
}
