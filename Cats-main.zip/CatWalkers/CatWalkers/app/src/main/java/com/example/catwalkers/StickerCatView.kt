package com.example.catwalkers

import android.animation.ValueAnimator
import android.content.Context
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Paint
import android.graphics.RectF
import android.view.animation.LinearInterpolator
import kotlin.math.PI
import kotlin.math.abs
import kotlin.math.sin

/**
 * Котик-стикер. Живёт на месте, у каждого настроения своё движение:
 * shake (злится, грустит, пугается), bounce (радуется), breathe (спит).
 */
class StickerCatView(
    context: Context,
    private val bmp: Bitmap,
    private val motion: String
) : CatBase(context) {

    private var phase = 0f
    private val animator = ValueAnimator.ofFloat(0f, 1f).apply {
        duration = if (motion == "breathe") 2400 else 700
        repeatCount = ValueAnimator.INFINITE
        interpolator = LinearInterpolator()
        addUpdateListener {
            phase = it.animatedValue as Float
            this@StickerCatView.invalidate()
        }
    }
    private val paint = Paint(Paint.ANTI_ALIAS_FLAG or Paint.FILTER_BITMAP_FLAG)
    private val dst = RectF()

    override fun onAttachedToWindow() {
        super.onAttachedToWindow()
        animator.start()
    }

    override fun onDetachedFromWindow() {
        animator.cancel()
        super.onDetachedFromWindow()
    }

    override fun onDraw(canvas: Canvas) {
        val w = width.toFloat()
        val h = height.toFloat()
        val t = phase * 2f * PI.toFloat()
        canvas.save()
        when (motion) {
            "shake" -> canvas.rotate(sin(t * 3f) * 3f, w / 2f, h)
            "bounce" -> {
                val k = 1f + abs(sin(t)) * 0.06f
                canvas.scale(k, 2f - k, w / 2f, h)
            }
            else -> canvas.scale(1f, 1f + sin(t) * 0.02f, w / 2f, h)
        }
        dst.set(0f, 0f, w, h)
        canvas.drawBitmap(bmp, null, dst, paint)
        canvas.restore()
    }
}
