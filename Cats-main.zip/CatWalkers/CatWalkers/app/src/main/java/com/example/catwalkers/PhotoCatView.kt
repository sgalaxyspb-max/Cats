package com.example.catwalkers

import android.animation.ValueAnimator
import android.content.Context
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Paint
import android.graphics.Rect
import android.graphics.RectF
import android.view.animation.LinearInterpolator
import kotlin.math.PI
import kotlin.math.abs
import kotlin.math.max
import kotlin.math.sin

/**
 * Котик из фото.
 *  - Когда идёт и фото «боком»: лапы и хвост качаются (сетка-деформация картинки).
 *  - Когда идёт, а фото другое: просто покачивается и подпрыгивает.
 *  - Когда отдыхает: меняется на фото «сидит» или «лежит» (если есть) и «дышит».
 * Спрайты должны смотреть вправо.
 */
class PhotoCatView(
    context: Context,
    private val walkBmp: Bitmap,
    private val restBmp: Bitmap?,
    private val longPx: Float,
    private val restFactor: Float,
    private val swingWhenWalking: Boolean
) : CatBase(context) {

    companion object {
        fun fit(b: Bitmap, longSide: Float): IntArray {
            val a = b.width.toFloat() / b.height
            val w = if (a >= 1f) longSide else longSide * a
            val h = if (a >= 1f) longSide / a else longSide
            return intArrayOf(w.toInt().coerceAtLeast(1), h.toInt().coerceAtLeast(1))
        }

        private const val COLS = 10
        private const val ROWS = 10
    }

    private var current: Bitmap = walkBmp
    private var swing = swingWhenWalking
    private var phase = 0f

    private val animator = ValueAnimator.ofFloat(0f, 1f).apply {
        duration = 650
        repeatCount = ValueAnimator.INFINITE
        interpolator = LinearInterpolator()
        addUpdateListener {
            phase = it.animatedValue as Float
            this@PhotoCatView.invalidate()
        }
    }
    private val paint = Paint(Paint.ANTI_ALIAS_FLAG or Paint.FILTER_BITMAP_FLAG)
    private val src = Rect(0, 0, walkBmp.width, walkBmp.height)
    private val dst = RectF()
    private val verts = FloatArray((COLS + 1) * (ROWS + 1) * 2)

    override fun onAttachedToWindow() {
        super.onAttachedToWindow()
        animator.start()
    }

    override fun onDetachedFromWindow() {
        animator.cancel()
        super.onDetachedFromWindow()
    }

    /** Смена позы: ходьба <-> сидит/лежит. Ноги остаются на одной линии «пола». */
    override fun onWalkingChanged(walking: Boolean) {
        val target = if (!walking && restBmp != null) restBmp else walkBmp
        if (target === current) return
        val lp = layoutParams ?: return
        val isRest = target !== walkBmp
        val d = fit(target, if (isRest) longPx * restFactor else longPx)
        translationX += (width - d[0]) / 2f
        translationY += (height - d[1]).toFloat()
        lp.width = d[0]
        lp.height = d[1]
        layoutParams = lp
        current = target
        src.set(0, 0, target.width, target.height)
        swing = !isRest && swingWhenWalking
    }

    override fun onDraw(canvas: Canvas) {
        val w = width.toFloat()
        val h = height.toFloat()
        val t = phase * 2f * PI.toFloat()
        canvas.save()
        if (walking && swing) {
            canvas.translate(0f, -abs(sin(t)) * h * 0.025f)
            canvas.rotate(sin(t) * 1.2f, w / 2f, h)
            canvas.scale(0.9f, 0.9f, w / 2f, h)
            fillMesh(w, h, t)
            canvas.drawBitmapMesh(current, COLS, ROWS, verts, 0, null, 0, paint)
        } else {
            if (walking) {
                canvas.translate(0f, -abs(sin(t)) * h * 0.05f)
                canvas.rotate(sin(t) * 3.5f, w / 2f, h)
            } else {
                canvas.scale(1f, 1f + sin(t) * 0.012f, w / 2f, h)
            }
            dst.set(0f, 0f, w, h)
            canvas.drawBitmap(current, src, dst, paint)
        }
        canvas.restore()
    }

    /** Сдвигаем узлы сетки: нижняя часть (лапы) и левая часть (хвост) качаются. */
    private fun fillMesh(w: Float, h: Float, t: Float) {
        var k = 0
        for (j in 0..ROWS) {
            val v = j.toFloat() / ROWS
            for (i in 0..COLS) {
                val u = i.toFloat() / COLS
                var x = u * w
                var y = v * h

                // лапы: чем ниже, тем сильнее качаются, соседние лапы в противофазе
                val leg = ((v - 0.6f) / 0.4f).coerceIn(0f, 1f)
                if (leg > 0f) {
                    val ph = t + u * 7f
                    x += sin(ph) * 0.07f * w * leg
                    y -= max(0f, sin(ph + 1.2f)) * 0.04f * h * leg
                }

                // хвост (слева, т.к. кот смотрит вправо)
                if (u < 0.3f && v < 0.85f) {
                    val wt = (0.3f - u) / 0.3f
                    y += sin(t + 1f) * 0.06f * h * wt * wt
                }

                verts[k++] = x
                verts[k++] = y
            }
        }
    }
}
