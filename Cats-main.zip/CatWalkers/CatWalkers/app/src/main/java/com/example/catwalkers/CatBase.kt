package com.example.catwalkers

import android.content.Context
import android.view.View

/** Общий предок для нарисованного и фото-котика. */
abstract class CatBase(context: Context) : View(context) {

    /** true — идёт, false — отдыхает (сидит или лежит). */
    var walking: Boolean = true
        set(value) {
            field = value
            onWalkingChanged(value)
        }

    protected open fun onWalkingChanged(walking: Boolean) {}
}
