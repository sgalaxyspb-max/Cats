package com.example.catwalkers

import android.Manifest
import android.app.Activity
import android.app.AlertDialog
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Matrix
import android.media.ExifInterface
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.view.Gravity
import android.view.ViewGroup
import android.widget.Button
import android.widget.EditText
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.RadioButton
import android.widget.RadioGroup
import android.widget.ScrollView
import android.widget.SeekBar
import android.widget.Switch
import android.widget.TextView
import android.widget.Toast
import com.google.mlkit.vision.common.InputImage
import com.google.mlkit.vision.segmentation.subject.SubjectSegmentation
import com.google.mlkit.vision.segmentation.subject.SubjectSegmenterOptions
import kotlin.math.max

class MainActivity : Activity() {

    companion object {
        private const val REQ_PICK = 100
    }

    private lateinit var status: TextView
    private lateinit var catList: LinearLayout
    private lateinit var addBtn: Button

    private val segmenter by lazy {
        SubjectSegmentation.getClient(
            SubjectSegmenterOptions.Builder().enableForegroundBitmap().build()
        )
    }

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    private fun toast(s: String) = Toast.makeText(this, s, Toast.LENGTH_LONG).show()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val prefs = getSharedPreferences(CatService.PREFS, MODE_PRIVATE)

        val col = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(24), dp(48), dp(24), dp(24))
        }

        col.addView(TextView(this).apply {
            text = "🐈 Котики на экране"
            textSize = 26f
            gravity = Gravity.CENTER
        })

        status = TextView(this).apply {
            textSize = 16f
            gravity = Gravity.CENTER
            setPadding(0, dp(16), 0, dp(24))
        }
        col.addView(status)

        val start = Button(this).apply { text = "Запустить котиков" }
        val stop = Button(this).apply { text = "Прогнать котиков" }
        col.addView(start)
        col.addView(stop)

        // ---- мои котики ----
        col.addView(TextView(this).apply {
            text = "Мои котики"
            textSize = 20f
            setPadding(0, dp(32), 0, dp(4))
        })
        col.addView(TextView(this).apply {
            text = "Выберите фото, где виден один котик целиком. Телефон сам вырежет его с фона. " +
                    "Для каждой кошки можно добавить несколько фото: идёт боком, сидит, лежит. " +
                    "На ходу лапы и хвост качаются у фото «идёт боком», а на остановке кошка " +
                    "меняется на фото «сидит» или «лежит»."
            textSize = 14f
            setPadding(0, 0, 0, dp(8))
        })
        addBtn = Button(this).apply { text = "Добавить котика из галереи" }
        col.addView(addBtn)
        catList = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        col.addView(catList)

        // ---- какие кошки выходят ----
        col.addView(TextView(this).apply {
            text = "Кто выходит на экран"
            textSize = 20f
            setPadding(0, dp(32), 0, dp(4))
        })
        val swPlusha = Switch(this).apply {
            text = "Плюша"
            isChecked = prefs.getBoolean(CatService.KEY_PLUSHA, true)
            setPadding(0, dp(8), 0, dp(8))
        }
        val swAlisa = Switch(this).apply {
            text = "Алиса"
            isChecked = prefs.getBoolean(CatService.KEY_ALISA, true)
            setPadding(0, dp(8), 0, dp(8))
        }
        swPlusha.setOnCheckedChangeListener { btn, on ->
            if (!on && !swAlisa.isChecked) {
                btn.isChecked = true
                toast("Хотя бы одна кошка должна быть включена")
            } else {
                prefs.edit().putBoolean(CatService.KEY_PLUSHA, on).apply()
            }
        }
        swAlisa.setOnCheckedChangeListener { btn, on ->
            if (!on && !swPlusha.isChecked) {
                btn.isChecked = true
                toast("Хотя бы одна кошка должна быть включена")
            } else {
                prefs.edit().putBoolean(CatService.KEY_ALISA, on).apply()
            }
        }
        col.addView(swPlusha)
        col.addView(swAlisa)

        col.addView(Switch(this).apply {
            text = "Котики-стикеры выглядывают из краёв"
            isChecked = prefs.getBoolean(CatService.KEY_STICKERS, true)
            setPadding(0, dp(16), 0, dp(4))
            setOnCheckedChangeListener { _, on ->
                prefs.edit().putBoolean(CatService.KEY_STICKERS, on).apply()
            }
        })

        col.addView(Switch(this).apply {
            text = "Рисованные котики тоже ходят"
            isChecked = prefs.getBoolean(CatService.KEY_DRAWN, false)
            setPadding(0, dp(16), 0, dp(8))
            setOnCheckedChangeListener { _, on ->
                prefs.edit().putBoolean(CatService.KEY_DRAWN, on).apply()
            }
        })

        // ---- частота ----
        val label = TextView(this).apply {
            textSize = 15f
            setPadding(0, dp(24), 0, dp(8))
        }
        val avg = prefs.getInt(CatService.KEY_AVG, 30)
        label.text = "Котик приходит примерно раз в $avg с"
        val seek = SeekBar(this).apply {
            max = 110
            progress = avg - 10
            setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
                override fun onProgressChanged(sb: SeekBar, p: Int, fromUser: Boolean) {
                    val v = p + 10
                    prefs.edit().putInt(CatService.KEY_AVG, v).apply()
                    label.text = "Котик приходит примерно раз в $v с"
                }

                override fun onStartTrackingTouch(sb: SeekBar) {}
                override fun onStopTrackingTouch(sb: SeekBar) {}
            })
        }
        col.addView(label)
        col.addView(seek)

        setContentView(ScrollView(this).apply { addView(col) })

        start.setOnClickListener {
            if (!Settings.canDrawOverlays(this)) {
                toast("Разрешите показ поверх других окон и вернитесь в приложение")
                startActivity(
                    Intent(
                        Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
                        Uri.parse("package:$packageName")
                    )
                )
                return@setOnClickListener
            }
            if (Build.VERSION.SDK_INT >= 33 &&
                checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) !=
                PackageManager.PERMISSION_GRANTED
            ) {
                requestPermissions(arrayOf(Manifest.permission.POST_NOTIFICATIONS), 1)
            }
            startForegroundService(Intent(this, CatService::class.java))
            status.postDelayed({ refresh() }, 600)
        }

        stop.setOnClickListener {
            stopService(Intent(this, CatService::class.java))
            status.postDelayed({ refresh() }, 300)
        }

        addBtn.setOnClickListener {
            val i = Intent(Intent.ACTION_GET_CONTENT)
                .setType("image/*")
                .addCategory(Intent.CATEGORY_OPENABLE)
            startActivityForResult(Intent.createChooser(i, "Фото котика"), REQ_PICK)
        }

        refreshCats()
    }

    override fun onResume() {
        super.onResume()
        refresh()
    }

    private fun refresh() {
        status.text = when {
            !Settings.canDrawOverlays(this) -> "Нужно разрешение «Поверх других окон»"
            CatService.running -> "Котики гуляют 🐾"
            else -> "Котики спят 😴"
        }
    }

    // ---------- список котиков ----------

    private fun refreshCats() {
        catList.removeAllViews()
        val files = CatStore.list(this)
        if (files.isEmpty()) {
            catList.addView(TextView(this).apply {
                text = "Пока пусто, гуляют нарисованные котики."
                textSize = 14f
                setPadding(0, dp(8), 0, 0)
            })
            return
        }
        for (f in files) {
            val row = LinearLayout(this).apply {
                orientation = LinearLayout.HORIZONTAL
                gravity = Gravity.CENTER_VERTICAL
                setPadding(0, dp(6), 0, dp(6))
            }
            val thumb = ImageView(this).apply {
                layoutParams = LinearLayout.LayoutParams(dp(72), dp(72))
                scaleType = ImageView.ScaleType.FIT_CENTER
                setBackgroundColor(0xFFEEEEEE.toInt())
                val o = BitmapFactory.Options().apply { inSampleSize = 4 }
                setImageBitmap(BitmapFactory.decodeFile(f.path, o))
            }
            val name = TextView(this).apply {
                text = CatStore.displayName(f)
                textSize = 16f
                layoutParams = LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f)
                setPadding(dp(12), 0, 0, 0)
            }
            val del = Button(this).apply {
                text = "Удалить"
                setOnClickListener {
                    CatStore.delete(f)
                    refreshCats()
                }
            }
            row.addView(thumb)
            row.addView(name)
            row.addView(del)
            catList.addView(row)
        }
    }

    // ---------- выбор фото и вырезка ----------

    @Deprecated("Deprecated in Java")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == REQ_PICK && resultCode == RESULT_OK) {
            val uri = data?.data ?: return
            processPhoto(uri)
        }
    }

    private fun processPhoto(uri: Uri) {
        val src = loadBitmap(uri)
        if (src == null) {
            toast("Не удалось открыть фото")
            return
        }
        addBtn.isEnabled = false
        toast("Вырезаю котика…")
        segmenter.process(InputImage.fromBitmap(src, 0))
            .addOnSuccessListener { res ->
                addBtn.isEnabled = true
                val fg = res.foregroundBitmap
                val cut = if (fg != null) cropAndScale(fg) else null
                if (cut == null) {
                    toast("Не нашёл котика на фото. Попробуйте другое.")
                } else {
                    showPreview(cut)
                }
            }
            .addOnFailureListener { e ->
                addBtn.isEnabled = true
                toast(
                    "Не получилось: ${e.message}. Если это первый запуск, подождите " +
                            "минуту-две (Google скачивает модель вырезки) и повторите."
                )
            }
    }

    private fun loadBitmap(uri: Uri): Bitmap? {
        try {
            val bounds = BitmapFactory.Options().apply { inJustDecodeBounds = true }
            contentResolver.openInputStream(uri)?.use { BitmapFactory.decodeStream(it, null, bounds) }
            var sample = 1
            while (max(bounds.outWidth, bounds.outHeight) / sample > 1600) sample *= 2
            val opts = BitmapFactory.Options().apply { inSampleSize = sample }
            val bmp = contentResolver.openInputStream(uri)?.use {
                BitmapFactory.decodeStream(it, null, opts)
            } ?: return null

            val orientation = contentResolver.openInputStream(uri)?.use {
                ExifInterface(it).getAttributeInt(
                    ExifInterface.TAG_ORIENTATION, ExifInterface.ORIENTATION_NORMAL
                )
            } ?: ExifInterface.ORIENTATION_NORMAL
            val degrees = when (orientation) {
                ExifInterface.ORIENTATION_ROTATE_90 -> 90f
                ExifInterface.ORIENTATION_ROTATE_180 -> 180f
                ExifInterface.ORIENTATION_ROTATE_270 -> 270f
                else -> 0f
            }
            if (degrees == 0f) return bmp
            val m = Matrix().apply { postRotate(degrees) }
            return Bitmap.createBitmap(bmp, 0, 0, bmp.width, bmp.height, m, true)
        } catch (e: Exception) {
            return null
        }
    }

    /** Обрезает прозрачные поля и уменьшает до разумного размера. */
    private fun cropAndScale(fg: Bitmap): Bitmap? {
        val w = fg.width
        val h = fg.height
        val px = IntArray(w * h)
        fg.getPixels(px, 0, w, 0, 0, w, h)
        var minX = w
        var minY = h
        var maxX = -1
        var maxY = -1
        for (y in 0 until h) {
            for (x in 0 until w) {
                if ((px[y * w + x] ushr 24) > 24) {
                    if (x < minX) minX = x
                    if (x > maxX) maxX = x
                    if (y < minY) minY = y
                    if (y > maxY) maxY = y
                }
            }
        }
        if (maxX < 0) return null
        val cropped = Bitmap.createBitmap(fg, minX, minY, maxX - minX + 1, maxY - minY + 1)
        val longSide = max(cropped.width, cropped.height)
        val target = 640f
        if (longSide <= target) return cropped
        val s = target / longSide
        return Bitmap.createScaledBitmap(
            cropped,
            (cropped.width * s).toInt().coerceAtLeast(1),
            (cropped.height * s).toInt().coerceAtLeast(1),
            true
        )
    }

    private fun showPreview(initial: Bitmap) {
        var current = initial
        val box = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(20), dp(8), dp(20), 0)
        }
        val catGroup = RadioGroup(this).apply { orientation = RadioGroup.HORIZONTAL }
        catGroup.addView(RadioButton(this).apply { id = 4000; text = "Плюша" })
        catGroup.addView(RadioButton(this).apply { id = 4001; text = "Алиса" })
        catGroup.check(4000)
        val iv = ImageView(this).apply {
            setImageBitmap(current)
            setBackgroundColor(0xFFCDEBCD.toInt())
            adjustViewBounds = true
            maxHeight = dp(220)
            scaleType = ImageView.ScaleType.FIT_CENTER
        }
        val poseGroup = RadioGroup(this).apply {
            orientation = RadioGroup.VERTICAL
            setPadding(0, dp(8), 0, 0)
        }
        val poses = listOf(
            "walk" to "Идёт или стоит боком",
            "sit" to "Сидит",
            "lie" to "Лежит"
        )
        poses.forEachIndexed { i, p ->
            poseGroup.addView(RadioButton(this).apply {
                id = 5000 + i
                text = p.second
                tag = p.first
            })
        }
        poseGroup.check(5000)
        box.addView(catGroup)
        box.addView(iv)
        box.addView(poseGroup)

        val dlg = AlertDialog.Builder(this)
            .setTitle("Смотрит вправо?")
            .setMessage(
                "Котик идёт туда, куда смотрит. Если смотрит влево, нажмите «Развернуть». " +
                        "Выберите, чья это кошка и какая поза на фото."
            )
            .setView(ScrollView(this).apply { addView(box) })
            .setPositiveButton("Сохранить") { _, _ ->
                val sel = poseGroup.findViewById<RadioButton>(poseGroup.checkedRadioButtonId)
                val pose = (sel?.tag as? String) ?: "walk"
                val catName = if (catGroup.checkedRadioButtonId == 4001) "Алиса" else "Плюша"
                CatStore.save(this, current, catName, pose)
                refreshCats()
            }
            .setNegativeButton("Отмена", null)
            .setNeutralButton("Развернуть", null)
            .create()
        dlg.show()
        dlg.getButton(AlertDialog.BUTTON_NEUTRAL).setOnClickListener {
            val m = Matrix().apply { postScale(-1f, 1f) }
            current = Bitmap.createBitmap(current, 0, 0, current.width, current.height, m, true)
            iv.setImageBitmap(current)
        }
    }
}
