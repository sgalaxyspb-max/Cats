package com.example.catwalkers

import android.animation.ValueAnimator
import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.Path
import android.view.animation.LinearInterpolator
import kotlin.math.PI
import kotlin.math.abs
import kotlin.math.cos
import kotlin.math.sin

private fun darker(c: Int, f: Float): Int = Color.rgb(
    (Color.red(c) * (1 - f)).toInt(),
    (Color.green(c) * (1 - f)).toInt(),
    (Color.blue(c) * (1 - f)).toInt()
)

private fun makePaint(c: Int, s: Paint.Style, w: Float = 1f): Paint =
    Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = c
        style = s
        strokeWidth = w
        strokeCap = Paint.Cap.ROUND
        strokeJoin = Paint.Join.ROUND
    }

/** Нарисованный кот, смотрит вправо. Для движения влево view отражается через scaleX = -1. */
class CatView(context: Context, furColor: Int) : CatBase(context) {

    private var phase = 0f
    private val animator = ValueAnimator.ofFloat(0f, 1f).apply {
        duration = 700
        repeatCount = ValueAnimator.INFINITE
        interpolator = LinearInterpolator()
        addUpdateListener {
            phase = it.animatedValue as Float
            this@CatView.invalidate()
        }
    }

    private val fur = makePaint(furColor, Paint.Style.FILL)
    private val outline = makePaint(0x66000000, Paint.Style.STROKE, 1.3f)
    private val tailPaint = makePaint(furColor, Paint.Style.STROKE, 7f)
    private val legPaint = makePaint(darker(furColor, 0.2f), Paint.Style.STROKE, 7f)
    private val stripe = makePaint(darker(furColor, 0.35f), Paint.Style.STROKE, 3f)
    private val innerEar = makePaint(0xFFFFB6C1.toInt(), Paint.Style.FILL)
    private val eye = makePaint(0xFF222222.toInt(), Paint.Style.FILL)
    private val eyeLine = makePaint(0xFF222222.toInt(), Paint.Style.STROKE, 1.6f)
    private val nose = makePaint(0xFFFF8FA3.toInt(), Paint.Style.FILL)
    private val whisker = makePaint(0xAA333333.toInt(), Paint.Style.STROKE, 0.8f)
    private val path = Path()

    override fun onAttachedToWindow() {
        super.onAttachedToWindow()
        animator.start()
    }

    override fun onDetachedFromWindow() {
        animator.cancel()
        super.onDetachedFromWindow()
    }

    override fun onDraw(canvas: Canvas) {
        val s = width / 100f
        canvas.save()
        canvas.scale(s, s)

        val t = phase * 2f * PI.toFloat()
        val bob = if (walking) -abs(sin(t)) * 1.5f else 0f
        canvas.translate(0f, bob)

        // хвост
        val wag = sin(if (walking) t else t * 0.5f) * 6f
        path.reset()
        path.moveTo(16f, 40f)
        path.quadTo(0f, 38f, 6f + wag, 14f)
        canvas.drawPath(path, tailPaint)

        // лапы (по диагоналям)
        drawLeg(canvas, 26f, t, 0f)
        drawLeg(canvas, 36f, t, PI.toFloat())
        drawLeg(canvas, 62f, t, PI.toFloat())
        drawLeg(canvas, 72f, t, 0f)

        // тело
        canvas.drawRoundRect(14f, 28f, 80f, 56f, 14f, 14f, fur)
        canvas.drawRoundRect(14f, 28f, 80f, 56f, 14f, 14f, outline)
        for (x in floatArrayOf(32f, 42f, 52f)) {
            canvas.drawLine(x, 30f, x + 3f, 39f, stripe)
        }

        // уши
        path.reset()
        path.moveTo(68f, 19f); path.lineTo(70f, 2f); path.lineTo(81f, 13f); path.close()
        canvas.drawPath(path, fur)
        canvas.drawPath(path, outline)
        path.reset()
        path.moveTo(79f, 13f); path.lineTo(90f, 2f); path.lineTo(93f, 19f); path.close()
        canvas.drawPath(path, fur)
        canvas.drawPath(path, outline)
        path.reset()
        path.moveTo(71.5f, 15f); path.lineTo(71.5f, 7f); path.lineTo(77f, 12f); path.close()
        canvas.drawPath(path, innerEar)
        path.reset()
        path.moveTo(83f, 12f); path.lineTo(88.5f, 7f); path.lineTo(88.5f, 15f); path.close()
        canvas.drawPath(path, innerEar)

        // голова
        canvas.drawCircle(80f, 28f, 15f, fur)
        canvas.drawCircle(80f, 28f, 15f, outline)

        // глаза
        val blink = !walking && phase > 0.9f
        if (blink) {
            canvas.drawLine(76.5f, 25f, 81.5f, 25f, eyeLine)
            canvas.drawLine(86.5f, 25f, 91.5f, 25f, eyeLine)
        } else {
            canvas.drawCircle(79f, 25f, 2.6f, eye)
            canvas.drawCircle(89f, 25f, 2.6f, eye)
        }

        // нос и усы
        canvas.drawCircle(93f, 29.5f, 2f, nose)
        canvas.drawLine(91f, 31f, 100f, 28f, whisker)
        canvas.drawLine(91f, 32.5f, 100f, 33f, whisker)

        canvas.restore()
    }

    private fun drawLeg(canvas: Canvas, x: Float, t: Float, offset: Float) {
        val a = if (walking) sin(t + offset) * 0.55f else 0f
        val x2 = x + sin(a) * 20f
        val y2 = 50f + cos(a) * 18f
        canvas.drawLine(x, 50f, x2, y2, legPaint)
    }
}
